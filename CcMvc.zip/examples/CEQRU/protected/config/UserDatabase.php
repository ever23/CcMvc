<?php

return['localhost', 'root', '', 'escuela'];

