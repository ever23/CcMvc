<center>
    <font color="black" face="arial" size="4"> 
    <center> <b> Ingresa los Datos del Estudiante"</b> </center>
    </font>

    <center >
        <form action="" method="POST">


            <label>C.I:</label>
            <INPUT name="cedu_estu">
            <br><br>
            <label> Nombre:</label>
            <INPUT NAME="nomb_estu">
            <br><br>
            <label> Apellido:</label>
            <INPUT NAME="apel_estu">
            <br><br>
            <label> Fecha de Nacimiento:</label>
            <INPUT type="date" NAME="fena_estu">

            <br><br>
            <label> Lugar de Nacimiento:</label>
            <INPUT NAME="luga_estu">
            <br><br>
            <label> Grado:</label>
            <INPUT NAME="grad_estu">
            <br><br>
            <label> Sección:</label>
            <INPUT NAME="secc_estu">
            <br><br>
            <label> Escolaridad:</label>
            <INPUT NAME="esco_estu">
            <br><br>

            <label> Codigo de Canaima:</label>
            <INPUT NAME="codi_cana">
            <br><br>
            <label>C.I Del Representante:</label>
            <INPUT name="ci_repr"><br><br>
            <label> Parentesco Con el Representante:</label>
            <INPUT NAME="pare_repr">
            <br><br>
            <br>


            <input type="submit" >
