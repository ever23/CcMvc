<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Cc\Mvc;

/**
 * Description of Layaut
 *
 * @author usuario
 */
class Layaut extends Model
{

    protected function Campos()
    {
        return [];
    }

//put your code here
}
